Entwicklerdokumentation: Carlito's Lernquiz


Überblick

Carlito's Lernquiz ist eine interaktive Progressive Web App (PWA), die als Lernwerkzeug für verschiedene Wissensbereiche entwickelt wurde. Mit einer Vielzahl von Fragen und Kategorien können Benutzer ihr Wissen in Mathematik, Informatik, Allgemeinwissen und Musiktheorie testen.

Technologiestack

Die Anwendung wurde mit grundlegenden Webtechnologien wie HTML, CSS und JavaScript entwickelt, ohne den Einsatz externer Frameworks oder Bibliotheken. Durch die Implementierung als PWA bietet sie verbesserte Benutzererfahrung und Offline-Funktionalität.

Funktionen

Fragen beantworten: Benutzer können aus verschiedenen Kategorien Fragen beantworten.
Feedback für Antworten: Sofortiges visuelles Feedback wird nach jeder Antwort gegeben.
Fortschrittsverfolgung: Ein Fortschrittsbalken zeigt den aktuellen Stand des Quiz an.
Neustart des Quiz: Benutzer haben die Möglichkeit, das Quiz jederzeit neu zu starten.
Installation und Ausführung
Herunterladen des Codes: Lade den Code herunter oder klonen ihn aus dem entsprechenden Repository.

Starten der Anwendung: 
Öffne die startseite.html-Datei in einem Webbrowser deiner Wahl.

Quiz spielen: 
Wähle eine Kategorie aus, beantworte die Fragen und überprüfe deine Antworten.

Anpassungen und Erweiterungen

Die Anwendung kann durch das Hinzufügen neuer Fragen, das Anpassen des Stylings oder das Erweitern der Kategorien angepasst und erweitert werden.

KI

Künstliche Intelligenz wurde vor allem im JavaScript-Code mit einbezogen, da einige Funktionen nicht funktionierten zmb. Die "Noten rendern" Funktion oder die Nutzung von Katex.
Gerade hier gab es enorme Probleme bei der Implementierung, weshalb KI eine entscheidene Rolle bei der Problemerkennung und Problemerhebung gespielt hat.

Probleme 

Wie vorhin bei "KI" kurz erwähnt, gab es enorme Probleme bei der Nutzung von Vexflow und Katex.
Manchmal renderten die Gleichungen nur im Fragecontainer jedoch im Antwortencontainer nicht. oder es wurde die Frage bei der Notenlehre angezeigt. Die Noten wurden nicht gerendert die Antwortmöglichkeiten ebenso wenig.
aber auch kleinere Dinge wie die Progressbar, welche immer visuell bei 10% statt 0% gestartet ist.




