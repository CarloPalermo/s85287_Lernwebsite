document.addEventListener('DOMContentLoaded', () => {
    const questionContainer = document.getElementById('frageText');
    const notationContainer = document.getElementById('notation');
    const answersContainer = document.getElementById('antwortContainer');
    const restartButton = document.getElementById('restartButton');
    const progressBar = document.querySelector('.progress2');
    let currentQuestionIndex = 0;
    let correctAnswersCount = 0; // Zähler für richtige Antworten
    let questions = [];
    const questionsPerRound = 10;
    const answerDelay = 1000;

    // Lade die Fragen aus der JSON-Datei
    function loadQuestions() {
        fetch('questions.json')
            .then(response => response.json())
            .then(data => {
                questions = data["teil-noten"].slice(0, questionsPerRound);
                displayQuestion();
            });
    }

    // Zeigt die aktuelle Frage und Antworten an
    function displayQuestion() {
        if (currentQuestionIndex < questions.length) {
            const currentQuestion = questions[currentQuestionIndex];
            questionContainer.innerText = currentQuestion.a;
            const correctAnswer = currentQuestion.note; // Korrekte Antwort ist die Note

            if (currentQuestion.note) {
                renderNote(formatNoteForVexFlow(currentQuestion.note), 'notation'); // Formatierung anpassen
            }

            // Antwortmöglichkeiten zufällig mischen
            const shuffledAnswers = shuffleArray(currentQuestion.l.slice(0)); // Kopie der Antwortmöglichkeiten erstellen und mischen

            // Antwortmöglichkeiten generieren
            answersContainer.innerHTML = ''; // Alte Antworten löschen
            shuffledAnswers.forEach((antwort, index) => {
                const antwortButton = document.createElement('button');
                antwortButton.textContent = antwort;
                antwortButton.addEventListener('click', () => handleAnswer(antwort, correctAnswer));
                answersContainer.appendChild(antwortButton);
            });
        } else {
            showResults();
        }
    }

    // Funktion für das Rendern von Noten mit VexFlow
    function renderNote(note, elementId) {
        const VF = Vex.Flow;
        const div = document.getElementById(elementId);
        div.innerHTML = ''; // Clear previous rendering
        const renderer = new VF.Renderer(div, VF.Renderer.Backends.SVG);
        renderer.resize(150, 150);
        const context = renderer.getContext();
        const stave = new VF.Stave(10, 40, 100);
        stave.addClef('treble').setContext(context).draw();
        const notes = [new VF.StaveNote({ keys: [note], duration: "q" })];
        const voice = new VF.Voice({ num_beats: 1, beat_value: 4 });
        voice.addTickables(notes);
        const formatter = new VF.Formatter().joinVoices([voice]).format([voice], 100);
        voice.draw(context, stave);
    }

    function formatNoteForVexFlow(note) {
        return note.charAt(0).toLowerCase() + '/' + note.charAt(1);
    }

    async function handleAnswer(selectedAnswer, correctAnswer) {
        // Antwort überprüfen
        const isCorrect = (selectedAnswer === correctAnswer);

        // Antwort markieren und kurze Pause einlegen
        const selectedIndex = Array.from(document.querySelectorAll('#antwortContainer button')).findIndex(btn => btn.textContent === selectedAnswer);
        markAnswer(selectedIndex, isCorrect);
        await sleep(answerDelay);

        if (isCorrect) {
            console.log('Richtig!');
            correctAnswersCount++; // Anzahl der richtigen Antworten erhöhen
        } else {
            console.log('Falsch!');
        }
        currentQuestionIndex++;
        displayQuestion();

        // Fortschrittsleiste aktualisieren
        updateProgressBar();
    }

    function markAnswer(selectedIndex, isCorrect) {
        const answerButtons = document.querySelectorAll('#antwortContainer button');
        answerButtons[selectedIndex].style.border = isCorrect ? '2px solid green' : '2px solid red';
    }

    function updateProgressBar() {
        const progress = (currentQuestionIndex / questionsPerRound) * 100;
        progressBar.style.width = `${progress}%`;
    }

    // Setze das Quiz zurück und zeige die erste Frage an
    restartButton.addEventListener('click', () => {
        currentQuestionIndex = 0;
        correctAnswersCount = 0; // Setze den Zähler für richtige Antworten zurück
        progressBar.style.width = '0%'; // Setze die Progressbar auf 0%
        displayQuestion();
    });

    // Zeige das Ergebnis des Quizzes an
    function showResults() {
        questionContainer.innerText = `Quiz beendet! Du hast ${correctAnswersCount} von ${questions.length} Fragen richtig beantwortet.`;
        answersContainer.innerHTML = '';
        notationContainer.innerHTML = ''; // Notation Container leeren
    }

    // Hilfsfunktionen
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Fragen laden
    loadQuestions();
});
