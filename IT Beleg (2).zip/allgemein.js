document.addEventListener('DOMContentLoaded', () => {
    const questionContainer = document.getElementById('frageText');
    const answersContainer = document.getElementById('antwortContainer');
    const restartButton = document.getElementById('restartButton');
    const progressBar = document.querySelector('.progress2');
    const answerDelay = 1000;
    let currentQuestionIndex = 0;
    let correctAnswersCount = 0; // Zähler für richtige Antworten
    let questions = [];

    // Lade die Fragen aus der JSON-Datei
    fetch('questions.json')
        .then(response => response.json())
        .then(data => {
            questions = data['teil-allgemeinwissen'];
            console.log('Fragen geladen:', questions);
            displayQuestion();
        })
        .catch(error => console.error('Fehler beim Laden der Fragen:', error));

    // Zeigt die aktuelle Frage und Antworten an
    function displayQuestion() {
        if (currentQuestionIndex < questions.length) {
            const question = questions[currentQuestionIndex];
            questionContainer.innerText = question.a;
            answersContainer.innerHTML = '';

            // Mische die Antworten zufällig
            const shuffledAnswers = shuffleArray(question.l);
            const correctAnswer = question.l[question.correctIndex];
            const correctAnswerIndex = shuffledAnswers.indexOf(correctAnswer);

            shuffledAnswers.forEach((answer, index) => {
                const button = document.createElement('button');
                button.classList.add("button2");
                button.innerText = answer;
                button.addEventListener('click', () => handleAnswer(index === correctAnswerIndex, button)); // Übergebe den Button
                answersContainer.appendChild(button);
            });

            const progress = ((currentQuestionIndex ) / questions.length) * 100;
            progressBar.style.width = `${progress}%`;
        } else {
            showResults(); // Zeige das Ergebnis am Ende des Quizzes
        }
    }

    // Funktion zum Mischen des Antwortarrays
    function shuffleArray(array) {
        const shuffledArray = array.slice(); // Kopie des Arrays erstellen
        for (let i = shuffledArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]]; // Vertausche Elemente
        }
        return shuffledArray;
    }

    // Verarbeite die Antwort und zeige die nächste Frage
    function handleAnswer(isCorrect, selectedButton) {
        if (isCorrect) {
            correctAnswersCount++;
            console.log('Richtig!');
        } else {
            console.log('Falsch!');
        }
        markAnswer(selectedButton, isCorrect); // Markiere die Antwort
        currentQuestionIndex++;
        displayQuestion();

    }
    function markAnswer(selectedButton, isCorrect) {
        // Definiert die Funktion zur Markierung der Antwort.
            selectedButton.style.border = isCorrect ? '2px solid green' : '2px solid red';
            // Setzt die Rahmenfarbe des Buttons je nach Richtigkeit der Antwort.
        }
    // Setze das Quiz zurück und zeige die erste Frage an
    restartButton.addEventListener('click', () => {
        currentQuestionIndex = 0;
        correctAnswersCount = 0; // Setze den Zähler für richtige Antworten zurück
        progressBar.style.width = '0%'; // Setze die Progressbar auf 0%
        displayQuestion();
    });

    // Zeige das Ergebnis des Quizzes an
    function showResults() {
        questionContainer.innerText = `Quiz beendet! Du hast ${correctAnswersCount} von ${questions.length} Fragen richtig beantwortet.`;
        answersContainer.innerHTML = '';
    }

});
